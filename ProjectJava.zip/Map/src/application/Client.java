package application;

import javafx.scene.paint.Color;

public class Client extends Person {
	private int cartCapasity;
	private String nextStop;
	
	
	Client(double x, double y, int w, int h, Color color){
		super(x, y, w, h, color );
	}
	
	public int getCartCapasity() {
		return cartCapasity;
	}
	public void setCartCapasity(int cartCapasity) {
		this.cartCapasity = cartCapasity;
	}
	public String getNextStop() {
		return nextStop;
	}
	public void setNextStop(String nextStop) {
		this.nextStop = nextStop;
	}

	public void buy() {
		
	}
	public void consume() {
		
	}
	public void travel() {
		
	}
}
