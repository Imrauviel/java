package application;

import java.util.ArrayList;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Group;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class Controller {
	
	private List<Supplier> allSuppliers;
	private Boolean isPause = false;

 

	@FXML
    private Button button1;
    
    @FXML
    private Button pasue;
    
    
    
    @FXML
    private Group group;

    @FXML
    private TextField count;
    
    @FXML
    private Pane pane;
    
    @FXML
    private TextField status;

    @FXML
    private Canvas canvas;
   
    @FXML
    public void onPress(ActionEvent event) {
    	
    	
    	//System.out.println(group.getChildren().size());
    	System.out.println("addingNewSupplier");
    	
    	int maxX = 68*20;
		int maxY = 26*20;
		int minX = 20*20;
		int minY = 25*20;
		int X = (int) ((Math.random() * (maxX - minX)) + minX);
		int Y = (int) ((Math.random() * (maxY - minY)) + minY);
		double px = (double) X;
		double py = (double) Y;     
    	Supplier supplier = new Supplier(X, Y, 20, 20, Color.RED);
    	supplier.setImage("car.png");
	  	 
        supplier.setLocation(px,py);
        group.getChildren().add(supplier);
        allSuppliers.add(supplier);
    }
      
	@FXML
	public void displayPosition(MouseEvent event) {
		double X = event.getX();
		double Y = event.getY();
		double rx = X%20;
		double ry = Y%20;
		double i = (X - rx)/20+75*(Y - ry)/20;
		status.setText("X = " + X + " Y = " + Y + " I = "+ i);
		count.setText("Number of Suppliers: " + Integer.toString(group.getChildren().size()-3));
    }
    
	@FXML
	public void Pause(ActionEvent event) {
		System.out.println("PAusing");
		setIsPause(true);
		
	}
	
    public void createGrid(Road roads) {
    	GraphicsContext gc = canvas.getGraphicsContext2D();
    	
        ArrayList<MapObject> mapObjectList = roads.draw();
                
        for (MapObject road : mapObjectList )
        	road.render( gc );
    }
    
    public void setList(List<Supplier> list) {
    	allSuppliers = list;
    }
    
    public List<Supplier> getList(){
    	return allSuppliers;
    }
    public Boolean getIsPause() {
		return isPause;
	}

	public void setIsPause(Boolean isPause) {
		this.isPause = isPause;
	}
}
