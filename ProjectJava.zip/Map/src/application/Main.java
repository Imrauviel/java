package application;
	


import java.io.IOException;
import java.util.ArrayList;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.fxml.FXMLLoader;


public class Main extends Application {
	
	List<Supplier> allSuppliers = new ArrayList<>();
	Group root;
	
	List<String> supplierNames = Stream.of("Ricky", "Julian", "Bubbles", "Jim", "Cory", "Trevor").collect(Collectors.toList());
	int n = 0;
	
	public void addSupplier(int i) {
		double X = (i % 75);
		double Y = ((i - X)/75);
		X *= 20;
		Y *= 20;
		System.out.println(X+" "+Y);
		Supplier supplier = new Supplier(X, Y, 20, 20, Color.TRANSPARENT );
		supplier.setImage("car.png");
		supplier.setOnMouseClicked((MouseEvent e) -> {
            
            try {// this all need to go to other class
            	Stage seconadryStage = new Stage();
            	FXMLLoader fxmlLoader = new FXMLLoader();
				Pane root2 = fxmlLoader.load(getClass().getResource("personWindow.fxml").openStream());
				TextArea inforation = new TextArea();
				inforation.setText("name: "+ supplier.getName() );
				root2.getChildren().add(inforation);
				seconadryStage.setScene(new Scene(root2, 200, 200));
				seconadryStage.showAndWait();
				
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
            
            
        });
		
        supplier.setName(supplierNames.get(n));
        n = (n+1)%6;
        allSuppliers.add(supplier);
        root.getChildren().add(supplier);
	}
	@Override
	public void start(Stage theStage) {
		try {
			
			
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("map.fxml"));
			root = fxmlLoader.load();
			Scene theScene = new Scene( root );
			theStage.setScene( theScene );

	   
	        Controller controller = fxmlLoader.getController();
	        
	        Road road = new Road();
	        controller.createGrid(road);
	        
	        for(int i = 0; i<5;i++)
	        {
	        	 addSupplier(320);
	        }
	         
	        int[] max = {0};

	        theStage.show();
	       
	        AnimationTimer timer = new AnimationTimer() {
	        	//double t = 0;
	            @Override
	            public void handle(long now) {
//	            	if(t > 1000) {
//	            		update();
//	            		t=0;
//	            	}
	            	if(controller.getIsPause())
	            	{
	            		this.stop();
	            	}
	            	
	                controller.setList(allSuppliers);
	            	allSuppliers.forEach(Supplier -> Supplier.move(road));
	            	allSuppliers.forEach(Supplier -> {
	            		if(Supplier.getGas()>=max[0]) 
	            		{
	            			max[0] = Supplier.getGas();
	            			Supplier.setImage("winner.png");
	            		}else {
	            			Supplier.setImage("car.png");
	            		}
	            			
	            	});
	            	allSuppliers = controller.getList();
	                //t+=0.16;
	            }
	        };

	        timer.start();

		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
