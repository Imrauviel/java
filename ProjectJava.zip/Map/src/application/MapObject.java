package application;

import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

public class MapObject extends Rectangle {
	
	private Image image;
	private double PosX;
	private double PosY;
	private double width;
	private double height;
	
	MapObject(){}
	
	MapObject(double x, double y, int w, int h, Color color){
		super(w, h, color);
		setTranslateX(x);
        setTranslateY(y);
        this.setLocation(x, y);
	}
	
	
    public void setLocation( double x, double y) {
    	PosX = x;
    	PosY = y;
    	
    }
    public double getPosX() {
    	return this.PosX;
    }

    public double getPosY() {
    	return this.PosY;
    }
    
	public double getWidths() { 
		return width;
	}
	public double getHeights() {
		return height;
	}

	
	public void render(GraphicsContext gc) 
	{
			gc.drawImage( image, PosX, PosY);
	}
	public Rectangle2D getBoundary()
    {
		return new Rectangle2D( PosX,  PosY , width, height);
    }

   public void setImage(Image i)
    {
        image = i;
        width = i.getWidth();
        height = i.getHeight();
    }

    public void setImage(String filename)
    {
        Image image = new Image(filename);
        ImagePattern imagePattern = new ImagePattern(image);
        this.setFill(imagePattern);
        setImage(image);
    }

}
