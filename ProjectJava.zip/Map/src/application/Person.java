package application;

import java.util.List;

import javafx.scene.paint.Color;

public class Person extends MapObject{
	private int ids;
	private String name;
	private Boolean isSick;
	private int PosI;
	//private int destynationI; // just to test AI for moving to point
	//private double destynationX;// --||--
	//private double destynationY;// --||--
	private int flag = 0;// 0: -75, 1:+1, 2:-75, 3:-1
	// I know this program look like cat brought in, but i have enough javafx for now and 
	// i want some funny programming 
	Person(double x, double y, int w, int h, Color color){
		super(x, y, w, h, color );
//		destynationI = 2985;
//		destynationX = (destynationI % 75);
//		destynationY = ((destynationI - destynationX)/75);
//		destynationX *= 20;
//		destynationY *= 20;
	}
	
	
	public void moveLeft(int velocity ) {
		setTranslateX(getTranslateX() - velocity);
			setLocation(getPosX() - velocity,  getPosY());
	}
	public void moveRight(int velocity) {
		setTranslateX(getTranslateX() + velocity);
		setLocation(getPosX() + velocity,  getPosY());
	}
	public void moveDown(int velocity)
	{
		setTranslateY(getTranslateY() - velocity);
		setLocation(getPosX(),  getPosY() - velocity);
	}
	public void moveUp(int velocity)
	{
		setTranslateY(getTranslateY() + velocity);
		setLocation(getPosX(),  getPosY() + velocity);
	}
	
	public void move(Road road, int velocity) {	
		//i know this function look very ugly, but it is just temporarily to
		//check if this sense of movement have sense 
		List<Integer> roadList = road.getRoads();
		int I = getI();
		//Integer[] hor = {0, 2};
		//Integer[] ver = {1, 3};
		
		int k = velocity;
		if( getPosX() > 35*20 && getPosX() < 36*20 )
		{
			int check = 0;
			if(flag == 1 || flag == 3) {
				if(roadList.contains(I-150)) {
					moveDown(k);
					flag = 2;
					check = 1;
			}else if(roadList.contains(I+150)) {
					moveUp(k);
					flag = 0;
					check =1;
			}
			}else {
				if(flag == 0 && !roadList.contains(I+75)) {
					flag = 3;
					moveLeft(k+3);
					moveLeft(k+3);
					
				}else if(flag == 2 && !roadList.contains(I-75)) {
					flag = 1;
					moveRight(k+3);
					moveRight(k+3);
				}
			}
			if (check == 0)
			{
				if(flag == 0) {
					if(roadList.contains(I+75)) {
						moveUp(k);
					}else {
						flag = 1;
					}
				}else if(flag == 1) {
					if(roadList.contains(I+1)) {
						moveRight(k);
					}else {
						flag = 2;
					}
				}else if(flag == 2) {
					if(roadList.contains(I-75)) {
						moveDown(k);
					}else {
						flag = 3;
					}
				}else if(flag == 3) {
					if(roadList.contains(I-1)) {
						moveLeft(k);
					}else{
						flag = 0; 
					}
				}
			}
			
		}else {
			if(flag == 0) {
			if(roadList.contains(I+75)) {
				moveUp(k);
			}else {
				flag = 1;
			}
		}else if(flag == 1) {
			if(roadList.contains(I+1)) {
				moveRight(k);
			}else {
				flag = 2;
			}
		}else if(flag == 2) {
			if(roadList.contains(I-75)) {
				moveDown(k);
			}else {
				flag = 3;
			}
		}else if(flag == 3) {
			if(roadList.contains(I-1)) {
				moveLeft(k);
			}else {
				flag = 0; 
			}
		}
		}
		
		
		updateI();
		//System.out.println(flag);
	}
	
	public void setLocation( double x, double y) {
		super.setLocation(x, y);
		PosI = (int) ((x - x%20)/20+75*(y - y%20)/20);
	}
	public int getI() {
		return PosI;
	}
	
	public void updateI() {
		double x = getPosX();
		double y = getPosY();
		PosI = (int) ((x - x%20)/20+75*(y - y%20)/20);
	}

	public int getIds() {
		return ids;
	}


	public void setIds(int id) {
		this.ids = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getIsSick() {
		return isSick;
	}

	public void setIsSick(Boolean isSick) {
		this.isSick = isSick;
	}
}
