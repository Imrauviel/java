package application;

public class Product {
	
	private String name;
	private String brand;
	private int bestBeforDate;
	private int id;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public int getBestBeforDate() {
		return bestBeforDate;
	}
	public void setBestBeforDate(int bestBeforDate) {
		this.bestBeforDate = bestBeforDate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}
