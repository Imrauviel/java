package application; 

public class Retail extends Shop {
	
	private int maxClients;
	
	public int getMaxClients() {
		return maxClients;
	}

	public void setMaxClients(int maxClients) {
		this.maxClients = maxClients;
	}

	public void creatSale() {
		
	}
}
