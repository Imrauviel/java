package application;

import java.util.*;


public class Road extends MapObject {
	
	private Boolean isTaken;
	private List<Integer> roadList = new ArrayList<>();
	
	public List<Integer> getRoads(){
		
		return this.roadList;
	}
	
	public Boolean getIsTaken() {
		return isTaken;
	}

	public void setIsTaken(Boolean isTaken) {
		this.isTaken = isTaken;
	}

	
	public ArrayList<MapObject> draw() {
		ArrayList<MapObject> mapObjectList = new ArrayList<MapObject>();
        
		List<Integer> roadUpList = new ArrayList<>();
		List<Integer> roadDownList = new ArrayList<>();
		List<Integer> roadLeftList = new ArrayList<>();
		List<Integer> roadRightList = new ArrayList<>();
		int i = 0;
		for (int y = 0; y < 45; y++)
        { 
        	for (int x =  0 ;x<75;x++)
        	{
        		if( x > 19 && x <70 && y>3 && y<40 ) {
        			if(y == 4 || y == 12 || y==17 || y==25 || y==30 || y==38) {
        				roadUpList.add(i);
	        		}
	        		if(y == 5 || y == 13 || y==18 || y==26 || y==31 || y==39) {
	        			roadDownList.add(i);
	        		}
	        		if(y != 14 && y != 15 &&y != 16 && y != 27 && y != 28 &&y != 29)
	        		{
	        			if( x==20 || x == 68)
		        		{
		        			roadLeftList.add(i);
		        		}
		        		if( x==21 || x == 69)
		        		{
		        			roadRightList.add(i);
		        		}
	        		}
	        		if(y == 14 || y == 15 || y == 16 || y == 27 || y == 28 || y == 29)
	        		{
	        			if(x==35)
	        			{
	        				roadLeftList.add(i);
	        			}
	        			if(x==36)
	        			{
	        				roadRightList.add(i);
	        			}
	        		}
	        		
        		}
        		
        		i+=1;
        	}
        	
        }
		roadList.addAll(roadRightList);
		roadList.addAll(roadLeftList);
		roadList.addAll(roadUpList);
		roadList.addAll(roadDownList);
		
		i = 0;
        for (int y = 0; y < 45; y++)
        { 
        	for (int x =  0 ;x<75;x++)
        	{
        		if(roadUpList.contains(i))
        		{
        			Road road = new Road();
		        	road.setImage("road5.png");
		            double px = road.getWidths()*x;
		            double py = road.getHeights()*y;          
		            road.setLocation(px,py);
		            mapObjectList.add( road );
		            
        		}else if (roadDownList.contains(i)) {
            			Road road = new Road();
    		        	road.setImage("road4.png");
    		            double px = road.getWidths()*x;
    		            double py = road.getHeights()*y;          
    		            road.setLocation(px,py);
    		            mapObjectList.add( road );
            	}else
            		if (roadLeftList.contains(i)) {
            			Road road = new Road();
    		        	road.setImage("roadleft.png");
    		        	double px = road.getWidths()*x;
    		            double py = road.getHeights()*y;          
    		            road.setLocation(px,py);
    		            mapObjectList.add( road );
            	}else if (roadRightList.contains(i)) {
        			Road road = new Road();
		        	road.setImage("roadright.png");
		            double px = road.getWidths()*x;
		            double py = road.getHeights()*y;          
		            road.setLocation(px,py);
		            mapObjectList.add( road );
        	}else{
            			if ( x > 15 ) {
            				MapObject road = new MapObject();
				        	road.setImage("grass.png");
				        	double px = road.getWidths()*x;
					        double py = road.getHeights()*y; 
					   
				            road.setLocation(px,py);
				            mapObjectList.add( road );
            			}
        				
        		}
        		
        			
        			i+=1;
        		}
        		
        	}

            
        
        return mapObjectList;
	}
	
}
