package application;

import java.util.*; 

public abstract class Shop extends MapObject {
	
	private String name;
	private String adress;
	private int maxProduct;
	
	private List<Product> products = new ArrayList<Product>();
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public int getMaxProduct() {
		return maxProduct;
	}
	public void setMaxProduct(int maxProduct) {
		this.maxProduct = maxProduct;
	}
	public void draw() {
		
	}
	
	
}
