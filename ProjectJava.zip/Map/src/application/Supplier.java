package application;
import java.util.ArrayList;
import java.util.List;

import javafx.scene.paint.Color;

public class Supplier extends Person {
	private int supplierId;
	private String companyName;
	private String carBrand;
	private int trunkCapasity;
	private List<Product> products = new ArrayList<Product>();
	private int gas; // for now total distance
	public Boolean isFirst;
	
	
	Supplier(double x, double y, int w, int h, Color color){
		super(x, y, w, h, color );
		
		
	}
	
	
	public int getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCarBrand() {
		return carBrand;
	}
	public void setCarBrand(String carBrand) {
		this.carBrand = carBrand;
	}
	public int getTrunkCapasity() {
		return trunkCapasity;
	}
	public void setTrunkCapasity(int trunkCapasity) {
		this.trunkCapasity = trunkCapasity;
	}
	public int getGas() {
		return gas;
	}
	public void setGas(int gas) {
		this.gas = gas;
	}
	public void stops() {
		
	}
	public void leaveProducts() {
		
	}
	public void getProducts() {
		
	}
	public void refuel() {
		gas = 0;
	}
	public void move(Road road) {
		java.util.Random random = new java.util.Random();
		int random_int = random.nextInt(3);
		super.move(road, random_int);
		gas+=random_int;
		
	}
	
}
