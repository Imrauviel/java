package application;

public class Wholesale extends Shop {
	public void createProducts() {
		
	}
}
